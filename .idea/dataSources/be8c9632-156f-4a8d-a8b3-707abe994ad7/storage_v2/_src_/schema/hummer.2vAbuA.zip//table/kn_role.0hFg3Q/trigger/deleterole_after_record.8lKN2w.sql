create trigger deleteRole_after_record
  after DELETE
  on kn_role
  for each row
  BEGIN
insert into kn_change_record (biz_name,biz_id,biz_type,action,biz_key,portal_type,created_date,able_flag) values ("kn_role",old.id,"ROLE","DELETE",old.code,"MXM",NOW(),0);
END;

