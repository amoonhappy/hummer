create trigger updateEmpOrg_after_record
  after UPDATE
  on kn_employee_organization
  for each row
  BEGIN
insert into kn_change_record (biz_name,biz_id,biz_type,action,biz_key,portal_type,created_date,able_flag) values ("kn_employee_organization",null,"EMPORG","UPDATE",concat(new.charge,",",new.major,",",new.emp_id,",",new.org_id,",",old.org_id,","),"MXM",NOW(),0);
END;

