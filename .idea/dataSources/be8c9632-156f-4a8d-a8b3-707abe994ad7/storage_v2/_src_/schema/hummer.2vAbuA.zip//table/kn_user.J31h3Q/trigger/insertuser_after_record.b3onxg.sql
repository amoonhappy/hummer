create trigger insertUser_after_record
  after INSERT
  on kn_user
  for each row
  BEGIN
insert into kn_change_record (biz_name,biz_id,biz_type,action,biz_key,portal_type,created_date,able_flag) values ("kn_user",new.id,"USER","ADD",new.login_name,"MXM",NOW(),0);
insert into kn_change_record (biz_name,biz_id,biz_type,action,biz_key,portal_type,created_date,able_flag) values ("kn_user",new.id,"USER","ADD",new.login_name,"OA",NOW(),0);
END;

